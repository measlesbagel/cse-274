import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.ArrayList;

public class Driver {
	static Scanner fin;
	static File[] files;
	static ArrayList<String> stopList = new ArrayList<>();
	static ArrayList<String> countList = new ArrayList<>();
	static ArrayList<String> wordList;
	static String[][] fileList;
	static Word[] wordCount;
	static Word[][] wordCountList;
	static ArrayList<ArrayList<String>> uniqueList = new ArrayList<>();

	public static void main(String[] args) throws FileNotFoundException {
		long start = System.currentTimeMillis();
		loadStopList("stoplist.txt");
		loadWordList("words.txt");
		loadData();
		
		printReport();
		
		long stop = System.currentTimeMillis();
		long tmr = stop - start;
		System.out.println("\nRuntime = " + tmr + " Millseconds");
	}

	private static void printReport() {
		countUnique();
		getFrequency();
		top5Words();
		countWordList();

	}

	private static void countWordList() {
		System.out.println("\nThe number of occurrences of each word in the file (words.txt) in each file");
		
		for(String s : countList) {
			System.out.printf("%s\n", s);
			System.out.println("\tFile       Frequency");
			System.out.println("\t=========  =========");
			
			for(int i =0; i < fileList.length; i++) {
				Word[] words = wordCountList[i];
				ArrayList<String> unique = uniqueList.get(i);
				
				if(unique.contains(s))
					System.out.printf("\t%-9s  %9d\n", files[i].getName(), words[unique.indexOf(s)].getCount());
				else 
					System.out.printf("\t%-9s  %9d\n", files[i].getName(), 0);
			}
		}
	}
	
	private static void top5Words() {
		System.out.println("\nThe top 5 most common words in each file: ");
		
		for(int i = 0; i < files.length; i++) {
			Word[] temp = wordCountList[i].clone();
			Arrays.sort(temp);
			
			System.out.printf("%-10s\n", files[i].getName());   
			System.out.println("\tRank  Word             Frequency");
			System.out.println("\t====  ====             =========");
			
			for(int x = 1; x < 6; x++) {
				System.out.printf("\t %-4d %-15s %10d\n", x, 
													temp[temp.length-x].getWord(), 
													temp[temp.length-x].getCount());
			}
		}
	}

	private static void getFrequency() {
		wordCountList = new Word[fileList.length][];
		
		for(int i = 0; i < fileList.length; i++) {
			
			String[] arr = fileList[i];
			String[] check = uniqueList.get(i).toArray(new String[0]);
			wordCount = new Word[check.length];
			
			for(int x = 0; x < wordCount.length; x++) {
				int count = 0;
				
				for(String y : arr) {
					if(check[x].equals(y)) count++;
				}
				
				wordCount[x] = new Word(check[x], count);
			}
			
			wordCountList[i] = wordCount;
		}
	
	}

	private static void countUnique() {
		System.out.println("The number of unique words in each file: ");
		System.out.println("File        Num of Unique Words");
		System.out.println("==========  ===================");
		
		for(int i =0; i < fileList.length; i++) {
			String[] arr = fileList[i];
			int count = 0;
			ArrayList<String> uniqueWords = new ArrayList<>();
			
			for(String s : arr) {
				if(!uniqueWords.contains(s) && !stopList.contains(s)) {
					uniqueWords.add(s);
					count++;
				}
			}
			System.out.printf("%-10s %20d\n", files[i].getName(), uniqueWords.size());
			uniqueList.add(uniqueWords);
		}
	}

	private static void loadWordList(String words) throws FileNotFoundException {
		fin = new Scanner(new File(words));
		while(fin.hasNext()) {
			countList.add(fin.next());
		}
		
		fin.close();
	}

	private static void loadStopList(String stop) throws FileNotFoundException {
		fin = new Scanner(new File(stop));
		while(fin.hasNext()) {
			stopList.add(fin.next());
		}
		
		fin.close();
	}

	private static void loadData() {
		fin = new Scanner(System.in);
		
		System.out.print("Enter the path to the folder: ");
		String data = fin.next();
		System.out.println();
		fin.close();
		
		File folder = new File(data);
        files = folder.listFiles();
        Arrays.sort(files);
        
        fileList = new String[files.length][];

        for (int i = 0; i < files.length; i++) {
            try {
            	File f = files[i];
            	wordList = new ArrayList<>();

				fin = new Scanner(f);
				while(fin.hasNext()) {
					wordList.add(fin.next().toLowerCase());
				}
				
				fileList[i] = wordList.toArray(new String[0]);
				fin.close();
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}           
        }          
	}
}
